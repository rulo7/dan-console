package es.raul.app.data.net;

/**
 * Created by djuarez on 17/12/15.
 */
public interface Service {

}